const fs = require("fs");

/*资源*/
var res = {
    /*公共*/
    //图片
    Back : "public/images/back.png", //头部部分
    BlackStar : "public/images/shape.png",
    LightStar : "public/images/light-star.png",
    FlyStar : "public/images/flay-star.png",
    ResultBg : "public/images/result-image-bg.png", //结束部分
    CelebrateGirl : "public/images/celebrate-girl.png",
    DoneNormal : "public/images/result-btn-done-normal.png",
    DonePress : "public/images/result-btn-done-pressed.png",
    Hand : "public/images/hand.png", //手势提示
    HandClick : "public/images/handclick.png",
    Sound : "public/images/sound_button.png",
    Circle : "public/images/click.png",
    Right : "public/images/right.png",
    //声音
    Button_audio : "public/audios/button.mp3",
    Right_audio : "public/audios/right.mp3",
    Star_audio : "public/audios/star.mp3",
    Win_audio : "public/audios/celebration.mp3",
    Wrong_audio : "public/audios/wrong.mp3",

    /*具体游戏*/
    //声音
    GameBg_audio : "audios/effect/game-bg.mp3",
};

/*预加载资源*/
var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}


fs.readdir("Normal/audios/voice","",function(err,arr){
    for (var i=0; i < arr.length; i++) {
        var pic = /\.(mp3)/g;
        if(pic.test(arr[i])){
            res[arr[i].replace(".mp3","_audio")] = 'audios/voice/' + arr[i];
        }else{
            console.log("错误"+arr[i]);
        }
    }

    fs.writeFile('resource.js', JSON.stringify(res), (err) => {
        if (err) throw err;
        console.log('文件已保存！');
    });
})

// fs.readdir("Normal/images/game1","",function(err,arr){
//     for (let i = 0; i < arr.length; i++) {
//         var pic = /\.(png)/g;
//         if(pic.test(arr[i])){
//             res[arr[i].replace(".png","")] = 'images/game1/' + arr[i];
//         }else{
//             console.log("错误"+arr[i]);
//         }
//     }

//     fs.writeFile('resource.js', JSON.stringify(res), (err) => {
//         if (err) throw err;
//         console.log('文件已保存！');
//     });
// })

// fs.readdir("Normal/images/game2","",function(err,arr){
//     for (let i = 0; i < arr.length; i++) {
//         var pic = /\.(png)/g;
//         if(pic.test(arr[i])){
//             res[arr[i].replace(".png","")] = 'images/game2/' + arr[i];
//         }else{
//             console.log("错误"+arr[i]);
//         }
//     }

//     fs.writeFile('resource.js', JSON.stringify(res), (err) => {
//         if (err) throw err;
//         console.log('文件已保存！');
//     });
// })
